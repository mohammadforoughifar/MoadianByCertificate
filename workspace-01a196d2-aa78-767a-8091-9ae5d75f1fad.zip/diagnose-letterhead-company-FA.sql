/* =====================================================================
   عیب‌یابی: چاپ روی سربرگ شرکت دیگر
   ---------------------------------------------------------------------
   فقط SELECT است. این را روی دیتابیس همان مشتری اجرا کنید.
   ===================================================================== */

/* ۱) شرکت‌ها و سربرگ ثبت‌شدهٔ هرکدام ------------------------------------
   - ردیف‌هایی که LetterheadFileName آن‌ها خالی است ⇒ چاپ نامهٔ داخلیِ
     همان شرکت خطا می‌دهد (قبلاً بی‌صدا سربرگ «فروغ» چاپ می‌شد).
   - اگر فایلی مثل forough-letterhead.pdf یا homepa_company3_... دیده شد،
     یعنی رکورد شرکت به فایل شرکت دیگری اشاره می‌کند. */
SELECT Id, Code, Name, IsActive,
       LetterheadFileName,
       وضعیت = CASE
                 WHEN LetterheadFileName IS NULL OR LTRIM(RTRIM(LetterheadFileName)) = '' THEN N'⚠ سربرگ تنظیم نشده'
                 WHEN LetterheadFileName LIKE N'%forough%'  THEN N'⚠ سربرگ پیش‌فرض/شرکت دیگر'
                 WHEN LetterheadFileName LIKE N'%homepa%'   THEN N'⚠ سربرگ هومپا'
                 WHEN LetterheadFileName LIKE N'%aria%'     THEN N'⚠ سربرگ آریا'
                 ELSE N'✔'
               END
FROM SystemCompanies
ORDER BY Id;

/* ۲) کدام شرکت «پیش‌فرض» یا تنها شرکت فعال است؟ -----------------------
   کاربرِ بدون ردیف «دسترسی شرکت» (مثلاً مدیر) به ترتیب حروف الفبا اولین
   شرکت فعال را می‌گیرد؛ اگر شرکت‌های نمونه (هومپا/آریا/فروغ) فعال مانده
   باشند، ممکن است همان انتخاب شود. */
SELECT c.Id, c.Name, c.IsActive,
       کاربران_با_دسترسی = (SELECT COUNT(*) FROM UserCompanyAccesses a WHERE a.CompanyId = c.Id),
       پیش‌فرض_برای     = (SELECT COUNT(*) FROM UserCompanyAccesses a WHERE a.CompanyId = c.Id AND a.IsDefault = 1)
FROM SystemCompanies c
ORDER BY c.IsActive DESC, c.Id;

/* ۳) کاربران و شرکت پیش‌فرضشان ---------------------------------------- */
SELECT a.UserId, u.Username, ا = (u.FirstName + N' ' + u.LastName),
       a.CompanyId, c.Name AS CompanyName, a.IsDefault
FROM UserCompanyAccesses a
JOIN Users u ON u.Id = a.UserId
LEFT JOIN SystemCompanies c ON c.Id = a.CompanyId
WHERE a.IsDefault = 1
ORDER BY a.UserId;

/* ۴) کاربران بدون هیچ ردیف دسترسی (پیش‌فرض گرفتن «اولین شرکت فعال») ---- */
SELECT u.Id, u.Username, (u.FirstName + N' ' + u.LastName) AS نام, u.Role, u.CompanyId
FROM Users u
WHERE u.IsActive = 1
  AND NOT EXISTS (SELECT 1 FROM UserCompanyAccesses a WHERE a.UserId = u.Id)
ORDER BY u.Id;

/* ۵) نامه‌های بدون شرکت (منبع چاپ روی سربرگ اشتباه) -------------------- */
SELECT 'نامهٔ صادره' AS نوع, COUNT(*) AS تعداد FROM OutgoingLetters WHERE IsDelete = 0 AND (CompanyId IS NULL OR CompanyId = 0)
UNION ALL
SELECT 'نامهٔ داخلی (بدون ستون شرکت)', COUNT(*) FROM InnerLetters WHERE IsDelete = 0
UNION ALL
SELECT 'نامهٔ وارده', COUNT(*) FROM IncomingLetters WHERE IsDelete = 0 AND (CompanyId IS NULL OR CompanyId = 0);

/* ۶) نامه‌هایی که CompanyId آن‌ها به شرکت غیرفعال/ناموجود اشاره می‌کند -- */
SELECT o.Id, o.Title, o.CompanyId, c.Name AS CompanyName, c.IsActive
FROM OutgoingLetters o
LEFT JOIN SystemCompanies c ON c.Id = o.CompanyId
WHERE o.IsDelete = 0 AND o.CompanyId IS NOT NULL
  AND (c.Id IS NULL OR c.IsActive = 0)
ORDER BY o.Id DESC;

/* =====================================================================
   اصلاح‌های داده‌ای — پیش از اجرا، شناسهٔ شرکت درست را جای‌گذاری کنید.
   ===================================================================== */
-- DECLARE @RightCompany int = 7;   -- شناسهٔ شرکت واقعی مشتری

/* الف) غیرفعال‌کردن شرکت‌های نمونه که مشتری به آن‌ها کاری ندارد
      (پس از اطمینان از اینکه هیچ داده‌ای به آن‌ها وابسته نیست) */
-- UPDATE SystemCompanies SET IsActive = 0 WHERE Id IN (3, 1003, 1005);

/* ب) ثبت سربرگ درست برای شرکت مشتری (فایل را از UI آپلود کردید، اینجا فقط مسیر) */
-- UPDATE SystemCompanies
--    SET LetterheadFileName = N'uploads/letterheads/company-7-letterhead.pdf'
--  WHERE Id = @RightCompany;

/* ج) اتصال نامه‌های بی‌شرکت به شرکت درست */
-- UPDATE OutgoingLetters SET CompanyId = @RightCompany WHERE IsDelete = 0 AND (CompanyId IS NULL OR CompanyId = 0);

/* د) پیش‌فرض‌کردن شرکت درست برای کاربران بدون دسترسی */
-- INSERT INTO UserCompanyAccesses (UserId, CompanyId, IsDefault)
-- SELECT u.Id, @RightCompany, 1 FROM Users u
-- WHERE u.IsActive = 1 AND NOT EXISTS (SELECT 1 FROM UserCompanyAccesses a WHERE a.UserId = u.Id);
