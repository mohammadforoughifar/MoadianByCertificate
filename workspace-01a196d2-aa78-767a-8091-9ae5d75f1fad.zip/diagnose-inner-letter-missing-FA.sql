/* =====================================================================
   عیب‌یابی: نامهٔ داخلی در کارتابل «ارسالی» دیده نمی‌شود ولی با جستجو پیدا می‌شود
   ---------------------------------------------------------------------
   نحوهٔ استفاده (SQL Server):
     1) @UserId  را با شناسهٔ همان کاربر جای‌گذاری کنید.
     2) @TitleLike را با بخشی از عنوان نامه(ها) جای‌گذاری کنید ('%...%').
     3) اسکریپت را در همان دیتابیس برنامه اجرا کنید (فقط SELECT است).
   خروجی: هر نامه با ستون Reason نشان می‌دهد چرا در «ارسالی» نیست.
   ===================================================================== */

DECLARE @UserId    int           = 0;            -- <<< شناسهٔ کاربر
DECLARE @TitleLike nvarchar(200) = N'%عنوان%';   -- <<< بخشی از عنوان نامه

/* ---------------------------------------------------------------------
   ۱) خلاصهٔ عددی — تفاوت «ساخته‌شده توسط کاربر» و «قابل نمایش در ارسالی»
   --------------------------------------------------------------------- */
SELECT
    ساخته‌شده      = SUM(CASE WHEN s.Id IS NOT NULL THEN 1 ELSE 0 END),
    حذف‌شده        = SUM(CASE WHEN l.IsDelete = 1 THEN 1 ELSE 0 END),
    منبع‌حذف‌شده    = SUM(CASE WHEN s.Id IS NULL OR s.IsDelete = 1 THEN 1 ELSE 0 END),
    بایگانی‌شده     = SUM(CASE WHEN b.BayeganiId IS NOT NULL THEN 1 ELSE 0 END),
    قابل‌نمایش     = SUM(CASE WHEN l.IsDelete = 0 AND s.Id IS NOT NULL AND s.IsDelete = 0
                                AND b.BayeganiId IS NULL THEN 1 ELSE 0 END)
FROM InnerLetters l
LEFT JOIN LetterSources  s ON s.Id = l.Id
LEFT JOIN LetterBayeganis b ON b.LetterId = l.Id AND b.UserId = @UserId
                            AND b.IsDelete = 0 AND b.IsFolder = 0
WHERE l.CreatorUserId = @UserId;

/* ---------------------------------------------------------------------
   ۲) فهرست نامه‌های مورد سؤال + دلیلِ نبودن در «ارسالی»
   --------------------------------------------------------------------- */
SELECT
    l.Id                AS نامه,
    l.LetterNumber      AS شماره,
    l.Title             AS عنوان,
    l.DateSabt          AS تاریخ‌ثبت,
    وضعیت‌بایگانی      = CASE WHEN b.BayeganiId IS NULL THEN '-' ELSE N'در بایگانی شخصی فرستنده' END,
    Reason =
        CASE
            WHEN l.IsDelete = 1
                THEN N'۱ — نامه حذف نرم شده (InnerLetters.IsDelete = 1)'
            WHEN s.Id IS NULL
                THEN N'۲ — ردیف LetterSources وجود ندارد (دادهٔ ناقص/مهاجرت نیمه‌کاره)'
            WHEN s.IsDelete = 1
                THEN N'۳ — LetterSources.IsDelete = 1 (منبع نامه حذف شده)'
            WHEN b.BayeganiId IS NOT NULL
                THEN N'۴ — فرستنده نامه را به بایگانی شخصی منتقل کرده (از «ارسالی» خارج می‌شود)'
            WHEN l.CreatorUserId <> @UserId AND e.ErjaId IS NULL
                THEN N'۵ — فرستندهٔ نامه این کاربر نیست (نامه به نام کاربر دیگری ثبت شده)'
            WHEN l.CreatorUserId <> @UserId AND e.ErjaId IS NOT NULL
                THEN N'۶ — این کاربر «گیرنده» است نه فرستنده؛ جای آن «دریافتی» است'
            ELSE N'۷ — داده سالم است؛ فقط ترتیب/صفحه‌بندی آن را پایین برده است'
        END,
    فرستنده = LTRIM(RTRIM(ISNULL(u.FirstName,'') + ' ' + ISNULL(u.LastName,''))) + ' (' + ISNULL(u.Username,'') + ')',
    گیرندگان = STUFF((
        SELECT N'، ' + CAST(r.ReciverUserId AS nvarchar(10))
        FROM Erjas r WHERE r.SourceId = l.Id AND r.IsDelete = 0
        FOR XML PATH('')), 1, 2, N'')
FROM InnerLetters l
LEFT JOIN LetterSources  s ON s.Id = l.Id
LEFT JOIN Users          u ON u.Id = l.CreatorUserId
LEFT JOIN LetterBayeganis b ON b.LetterId = l.Id AND b.UserId = @UserId
                            AND b.IsDelete = 0 AND b.IsFolder = 0
OUTER APPLY (
    SELECT TOP 1 r.ErjaId
    FROM Erjas r
    WHERE r.SourceId = l.Id AND r.ReciverUserId = @UserId AND r.IsDelete = 0
) e
WHERE l.Title LIKE @TitleLike OR l.LetterNumber LIKE @TitleLike
ORDER BY l.Id DESC;

/* ---------------------------------------------------------------------
   ۳) شکِ «اکانت تکراری» — کاربرانی با نام مشابه که ممکن است نامه به آن‌ها خورده باشد
   --------------------------------------------------------------------- */
SELECT u.Id, u.Username, u.FirstName, u.LastName, u.IsActive,
       تعداد‌نامه‌های‌داخلی = (SELECT COUNT(*) FROM InnerLetters l WHERE l.CreatorUserId = u.Id AND l.IsDelete = 0),
       تعداد‌نامه‌های‌صادره = (SELECT COUNT(*) FROM OutgoingLetters o WHERE o.CreatorUserId = u.Id AND o.IsDelete = 0)
FROM Users u
WHERE u.Id = @UserId
   OR u.Username IN (SELECT Username FROM Users WHERE Id = @UserId)
   OR (u.FirstName = (SELECT FirstName FROM Users WHERE Id = @UserId)
       AND u.LastName = (SELECT LastName FROM Users WHERE Id = @UserId))
ORDER BY u.Id;

/* ---------------------------------------------------------------------
   ۴) سازگاری ترتیب: نامه‌هایی که «شناسه» و «تاریخ ثبت» آن‌ها هم‌جهت نیست
       (سرور با Id نزولی صفحه‌بندی می‌کند ولی رابط با تاریخ نزولی نمایش می‌دهد)
   --------------------------------------------------------------------- */
;WITH c AS (
    SELECT l.Id, l.DateSabt,
           ROW_NUMBER() OVER (ORDER BY l.Id DESC)       AS رتبه‌شناسه,
           ROW_NUMBER() OVER (ORDER BY l.DateSabt DESC) AS رتبه‌تاریخ
    FROM InnerLetters l
    WHERE l.CreatorUserId = @UserId AND l.IsDelete = 0
)
SELECT Id AS نامه, DateSabt AS تاریخ, رتبه‌شناسه, رتبه‌تاریخ,
       اختلاف = ABS(رتبه‌شناسه - رتبه‌تاریخ)
FROM c
WHERE ABS(رتبه‌شناسه - رتبه‌تاریخ) > 5
ORDER BY اختلاف DESC;
