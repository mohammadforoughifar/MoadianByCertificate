# -*- coding: utf-8 -*-
"""ساخت گزارش کار روزانه (docx راست‌به‌چپ) — ترتیب عناصر OOXML مطابق اسکیما رعایت می‌شود."""
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

FONT = "Tahoma"
DARK = RGBColor(0x1F, 0x29, 0x37)
BLUE = RGBColor(0x1D, 0x4E, 0xD8)
GREY = RGBColor(0x55, 0x60, 0x6E)

RPR_AFTER_RTL = ('w:cs', 'w:em', 'w:lang', 'w:eastAsianLayout', 'w:specVanish', 'w:oMath')
PPR_BIDI_BEFORE = ('w:adjustRightInd', 'w:snapToGrid', 'w:spacing', 'w:ind',
                   'w:contextualSpacing', 'w:mirrorIndents', 'w:suppressOverlap', 'w:jc',
                   'w:textDirection', 'w:textAlignment', 'w:textboxTightWrap', 'w:outlineLvl',
                   'w:divId', 'w:cnfStyle', 'w:rPr', 'w:sectPr', 'w:pPrChange')
PPR_BDR_BEFORE = ('w:shd', 'w:tabs', 'w:suppressAutoHyphens', 'w:kinsoku', 'w:wordWrap',
                  'w:overflowPunct', 'w:topLinePunct', 'w:autoSpaceDE', 'w:autoSpaceDN',
                  'w:bidi', 'w:adjustRightInd', 'w:snapToGrid', 'w:spacing', 'w:ind',
                  'w:contextualSpacing', 'w:mirrorIndents', 'w:suppressOverlap', 'w:jc',
                  'w:textDirection', 'w:textAlignment', 'w:textboxTightWrap', 'w:outlineLvl',
                  'w:divId', 'w:cnfStyle', 'w:rPr', 'w:sectPr', 'w:pPrChange')

doc = Document()

# ---------- تنظیم صفحه و جهت RTL ----------
sec = doc.sections[0]
sec.top_margin = Cm(1.8); sec.bottom_margin = Cm(1.8)
sec.left_margin = Cm(2.0); sec.right_margin = Cm(2.0)
sectPr = sec._sectPr
bidi = OxmlElement('w:bidi')
sectPr.insert_element_before(bidi, 'w:rtlGutter', 'w:docGrid', 'w:printerSettings', 'w:sectPrChange')

# ---------- استایل پایه ----------
normal = doc.styles['Normal']
normal.font.name = FONT
normal.font.size = Pt(10.5)
normal.font.color.rgb = DARK
nrpr = normal.element.get_or_add_rPr()
nrf = nrpr.get_or_add_rFonts()
nrf.set(qn('w:cs'), FONT); nrf.set(qn('w:ascii'), FONT); nrf.set(qn('w:hAnsi'), FONT)
nsz = OxmlElement('w:szCs'); nsz.set(qn('w:val'), '21')
nrpr.insert_element_before(nsz, 'w:highlight', 'w:u', 'w:effect', 'w:bdr', 'w:shd', 'w:fitText',
                           'w:vertAlign', 'w:rtl')

def rtl_para(p, space_after=4, space_before=0, align=WD_ALIGN_PARAGRAPH.RIGHT):
    p.alignment = align
    p.paragraph_format.space_after = Pt(space_after)
    p.paragraph_format.space_before = Pt(space_before)
    pPr = p._p.get_or_add_pPr()
    b = OxmlElement('w:bidi')
    pPr.insert_element_before(b, *PPR_BIDI_BEFORE)
    return p

def add_run(p, text, size=10.5, bold=False, color=None):
    r = p.add_run(text)
    r.font.size = Pt(size)
    r.bold = bold
    if color is not None:
        r.font.color.rgb = color
    rpr = r._element.get_or_add_rPr()
    rf = rpr.get_or_add_rFonts()
    rf.set(qn('w:ascii'), FONT); rf.set(qn('w:hAnsi'), FONT); rf.set(qn('w:cs'), FONT)
    szcs = OxmlElement('w:szCs'); szcs.set(qn('w:val'), str(int(size * 2)))
    rpr.insert_element_before(szcs, 'w:highlight', 'w:u', 'w:effect', 'w:bdr', 'w:shd',
                              'w:fitText', 'w:vertAlign', 'w:rtl')
    r.font.rtl = True
    return r

def para(text, size=10.5, bold=False, color=None, space_after=4, space_before=0):
    p = doc.add_paragraph(); rtl_para(p, space_after, space_before)
    add_run(p, text, size, bold, color)
    return p

def bullet(text, size=10.5):
    p = doc.add_paragraph(); rtl_para(p, 2.5)
    p.paragraph_format.right_indent = Cm(0.6)
    p.paragraph_format.first_line_indent = Cm(-0.4)
    add_run(p, "•  ", size, True, BLUE)
    add_run(p, text, size)
    return p

def heading(text, size=12.5):
    p = doc.add_paragraph(); rtl_para(p, 3, 11)
    add_run(p, text, size, True, BLUE)
    return p

def divider():
    p = doc.add_paragraph(); rtl_para(p, 3)
    pPr = p._p.get_or_add_pPr()
    pbdr = OxmlElement('w:pBdr')
    bottom = OxmlElement('w:bottom')
    bottom.set(qn('w:val'), 'single'); bottom.set(qn('w:sz'), '6')
    bottom.set(qn('w:space'), '1'); bottom.set(qn('w:color'), 'D6DEEA')
    pbdr.append(bottom)
    pPr.insert_element_before(pbdr, *PPR_BDR_BEFORE)

# ==================== سرصفحه ====================
p = doc.add_paragraph(); rtl_para(p, 1)
add_run(p, "گزارش کار روزانه", 19, True, DARK)
p = doc.add_paragraph(); rtl_para(p, 3)
add_run(p, "توسعهٔ نرم‌افزار جامع فروغ آریا — نسخهٔ وب (Blazor WebAssembly / .NET 8)", 11, False, GREY)
divider()

p = doc.add_paragraph(); rtl_para(p, 1)
add_run(p, "تاریخ گزارش: ", 10.5, True); add_run(p, "سه‌شنبه ۵ آبان ۱۴۰۵  (۲۷ اکتبر ۲۰۲۶)", 10.5)
p = doc.add_paragraph(); rtl_para(p, 1)
add_run(p, "تهیه‌کننده: ", 10.5, True); add_run(p, "………………………………", 10.5)
p = doc.add_paragraph(); rtl_para(p, 1)
add_run(p, "مخزن کد: ", 10.5, True)
add_run(p, "TotallCollectionSoftware — شاخهٔ main  |  وضعیت: همهٔ تغییرات کامیت و پوش شده است", 10.5)
divider()

# ==================== ۱) خلاصه مدیریتی ====================
heading("۱) خلاصهٔ مدیریتی")
para("در این روز ۳۱ کامیت روی شاخهٔ main ثبت و پوش شد. تمرکز کار روی چهار محور بود: «کارتابل نامه‌ها و بایگانی»، "
     "«دستور کار»، «اعلان‌ها و ارجاع» و «پست الکترونیک». در کنار قابلیت‌های تازه، چند مورد از خطاهای گزارش‌شدهٔ "
     "کاربران نیز رفع شد؛ مهم‌ترین‌شان باگ «گم‌شدن نامه پس از خروج از بایگانی» و «به‌هم‌ریختگی متن دستور کارِ "
     "ساخته‌شده از نامه/ایمیل» بود.")
para("هر تغییر پیش از پوش، با بازرسی خودکار قالب‌های Razor و رفع خطاهای بیلد (RZ1011/RZ2005/CS) کنترل شد و "
     "راهنمای همان بخش نیز به‌صورت هم‌زمان به‌روزرسانی شد.")

rows = [
    ("حوزهٔ کاری", "تعداد تغییر شاخص", "وضعیت"),
    ("کارتابل نامه‌ها (داخلی / صادره / وارده)", "۷", "تحویل شد"),
    ("بایگانی و خروج از بایگانی", "۴", "تحویل شد"),
    ("دستور کار", "۹", "تحویل شد"),
    ("گردش و ارجاع نامه", "۳", "تحویل شد"),
    ("اعلان‌ها و کارتابل من", "۳", "تحویل شد"),
    ("پست الکترونیک", "۴", "تحویل شد"),
    ("رابط کاربری، برندینگ و راهنماها", "۵", "تحویل شد"),
    ("کیفیت، بیلد و مستندسازی", "۴", "تحویل شد"),
]
table = doc.add_table(rows=0, cols=3)
table.style = 'Table Grid'
table.alignment = WD_TABLE_ALIGNMENT.CENTER
tblPr = table._tbl.tblPr
bv = OxmlElement('w:bidiVisual')
tblPr.insert_element_before(bv, 'w:tblStyleRowBandSize', 'w:tblStyleColBandSize', 'w:tblW', 'w:jc',
                            'w:tblCellSpacing', 'w:tblInd', 'w:tblBorders', 'w:shd', 'w:tblLayout',
                            'w:tblCellMar', 'w:tblLook', 'w:tblCaption', 'w:tblDescription')
for i, (c1, c2, c3) in enumerate(rows):
    cells = table.add_row().cells
    for cell, text in ((cells[0], c1), (cells[1], c2), (cells[2], c3)):
        cell.text = ""
        pp = cell.paragraphs[0]
        rtl_para(pp, 1)
        add_run(pp, text, 9.5, i == 0)
        if i == 0:
            shd = OxmlElement('w:shd')
            shd.set(qn('w:val'), 'clear'); shd.set(qn('w:fill'), 'E8EFFB')
            cell._tc.get_or_add_tcPr().insert_element_before(
                shd, 'w:noWrap', 'w:tcMar', 'w:textDirection', 'w:tcFitText', 'w:vAlign', 'w:hideMark')

para("", 6)

# ==================== ۲) کارتابل نامه‌ها ====================
heading("۲) کارتابل نامه‌ها (داخلی، صادره، وارده)")
bullet("کارتابل «نامهٔ وارده — دریافتی»: صفحه‌بندی کامل سمت سرور (تعداد در صفحه، صفحهٔ اول/قبلی/بعدی/آخر، «رفتن به صفحه» و متن «نمایش X تا Y از Z») و چیپ‌های فیلتر سمت سرور با شمارنده.")
bullet("یکسان‌سازی ترتیب صفحه‌بندی با ترتیب نمایش در هر سه کارتابل، تا نامه‌ها بین صفحات جابه‌جا نشوند.")
bullet("حذف باکس «گردش و پاسخ‌های نامه» از جزئیات نامهٔ وارده (دکمهٔ «گردش نامه» همچنان در دسترس است).")
bullet("نمایش جزئیات نامهٔ وارده در ریدر، هم‌سطح نامهٔ داخلی شد (اطلاعات، پیوست‌ها و عملیات مجاز).")

heading("۳) بایگانی نامه‌ها")
bullet("دکمهٔ «انطباق و بایگانی» حالا فرم انتخاب پوشه را باز می‌کند (پیش‌تر بدون پرسش، وضعیت بایگانی فوراً تغییر می‌کرد).")
bullet("نامهٔ بایگانی‌شده همیشه در ریل «بایگانی» دیده می‌شود: ساخت خودکار رکورد درخت برای داده‌های قدیمی و فهرست جایگزین «بایگانی‌شده‌های بدون پوشه».")
bullet("رفع باگ گزارش‌شده: پس از «خروج از بایگانی»، نامه از بایگانی حذف می‌شد ولی به «دریافتی» برنمی‌گشت. "
       "ریشهٔ خطا: نامهٔ وارده دو پرچم بایگانی مستقل دارد (پرچم ارجاعِ گیرنده و پرچم ثبت‌کننده) و فقط یکی آزاد می‌شد. "
       "اکنون مسیر واحدِ خروج از بایگانی، گره درخت و همهٔ پرچم‌های همان کاربر را با هم آزاد می‌کند.")
bullet("حذف پوشهٔ بایگانی به‌صورت آبشاری: نامه‌های داخل زیرپوشه‌ها هم از بایگانی خارج و به فهرست برمی‌گردند.")

heading("۴) دستور کار")
bullet("افزودن ستون «تصمیم دستوردهنده» به فهرست (دسکتاپ، موبایل و خروجی اکسل/PDF) همراه با فیلتر سروری: تأییدشده / ردشده / بی‌تصمیم / در انتظار پاسخ.")
bullet("همهٔ فیلترها سمت سرور اعمال می‌شوند؛ «در انتظار پاسخ» در تب «محول به من» با ملاک پاسخ خودِ کاربر محاسبه می‌شود.")
bullet("شمارندهٔ تب‌ها و کارت «در انتظار پاسخ» بر اساس هر سطر دستور کار (نه تعداد گیرندگان) اصلاح شد.")
bullet("جلوگیری از ثبت تکراری با دوبار کلیک: قفل سمت کلاینت + کلید یکتا و کنترل ضدِ تکرار در سرور.")
bullet("ساخت دستور کار از نامه، دیگر نامه را در «دریافتی» خودِ کاربر قرار نمی‌دهد (حذف خودارجاعی در هستهٔ دسترسی و پاک‌سازی ردیف‌های قبلی).")
bullet("پیش‌پُرشدن فرم دستور کار از نامهٔ وارده/صادره (عنوان، متن و گیرندگان گردش) و اعمال دسترسی یکسان برای عضو گردش در هر سه نوع نامه.")
bullet("رفع به‌هم‌ریختگی متن دستور کارِ ساخته‌شده از نامه/ایمیل: متن با قالب خوانا منتقل می‌شود؛ تگ‌های HTML و کدهای escape‌شده دیگر روی صفحه دیده نمی‌شوند.")

heading("۵) گردش و ارجاع نامه")
bullet("اصلاح نمای درختواره/فلوچارتی گردش: گیرنده زیر ارجاع‌دهندهٔ خودش نمایش داده می‌شود (رفع نبودن C زیر B) و والدِ ارجاع برای داده‌های قدیمی هم استنتاج می‌شود.")
bullet("افزودن عملگر «جهت استحضار» به عملگرهای ارجاع.")
bullet("دکمهٔ «+» در فرم ارجاع هر سه نوع نامه برای ساخت عملگر تازه؛ عملگر بلافاصله ساخته و انتخاب می‌شود و برای همهٔ کاربران قابل استفاده است.")

heading("۶) اعلان‌ها و کارتابل من")
bullet("رفع ناهم‌خوانی گزارش‌شده: نشان «+۹۹» روی زنگوله با فهرست اعلان‌ها هم‌خوان شد؛ اندپوینت صفحه‌بندی اعلان‌ها اضافه و همهٔ اعلان‌ها قابل مشاهده شدند.")
bullet("«کارتابل من»: پیام‌ها به‌جای «نمایش بیشتر» صفحه‌بندی کامل دارند (تعداد در صفحه، ناوبری صفحات، رفتن به صفحه و «نمایش X تا Y از Z»).")

heading("۷) پست الکترونیک")
bullet("جستجو و اعمال فیلتر با دکمه، همراه با نوار پیشرفت و دکمهٔ پاک‌کردن.")
bullet("انتخاب پیش‌فرض حساب ایمیل = حسابی که تازه‌ترین پیام را دارد (بر اساس LastMessageAt و نمایش تاریخ در فهرست انتخاب).")
bullet("تصاویر درون‌متن داخل بدنهٔ ایمیل نمایش داده می‌شوند (نه به‌عنوان پیوست) و قالب جدول‌های ایمیل حفظ می‌شود.")
bullet("تبدیل ایمیل به نامه: بدنهٔ ایمیل پیش از انتقال پاک‌سازی می‌شود؛ استایل‌های داخلی ایمیل (که کادر فرم را تیره می‌کرد) حذف و متن روشن به تیره تبدیل می‌شود تا نامه روی کاغذ سفید خوانا بماند.")

heading("۸) رابط کاربری، برندینگ و راهنماها")
bullet("آیکن تب مرورگر با نشان فروغ آریا جایگزین شد (SVG، PNG چندسایز، ICO و Apple-Touch) و manifest هم‌گام شد.")
bullet("صفحهٔ ورود: حذف آیکن برند و غیرفعال‌کردن پیشنهاد نام کاربری/رمز ذخیره‌شدهٔ مرورگر.")
bullet("راهنمای سامانهٔ فروشگاهی: صفحهٔ راهنمای اختصاصی به‌همراه دسترسی ShopGuide در تنظیمات نقش‌ها، منو و گارد مسیر.")
bullet("راهنماهای کارتابل نامه‌ها، دبیرخانهٔ یکپارچه، پست الکترونیک و ارجاع هم‌زمان با تغییرات به‌روزرسانی شدند.")

heading("۹) کیفیت، بیلد و مستندسازی")
bullet("رفع خطاهای بیلد: RZ1011/RZ2005 (استفادهٔ @page داخل متن ⇒ @(page))، CS1061 و نقل‌قول تودرتوی صفت‌ها در @onclick.")
bullet("رفع خطای تبدیل webcil در بیلد با wasm pack نسخهٔ ۱۰ روی پروژهٔ net8 (غیرفعال‌کردن WasmEnableWebcil) به‌همراه مستند راهنما.")
bullet("بازرسی خودکار قالب‌های Razor پیش از هر پوش، برای جلوگیری از بازگشت خطاهای بیلد.")
bullet("همهٔ تغییرات امروز روی شاخهٔ main کامیت و پوش شده‌اند؛ شاخهٔ arena/workorder-decision-column نیز هم‌گام است.")

heading("۱۰) در دست اقدام و پیشنهادها")
bullet("طرح «مالکیت یکپارچهٔ دبیرخانه»: سند پیشنهادی آماده است و برای شروع پیاده‌سازی منتظر تأیید است.")
bullet("در صورت نیاز، اصلاح یک‌بارهٔ متن دستور کارهایی که پیش از این اصلاح از نامه ساخته شده‌اند (اسکریپت اصلاح داده).")
bullet("تکمیل راهنمای بخش‌های منابع انسانی و انبار و یکسان‌سازی تقویم شمسی در فرم‌های باقی‌مانده.")

divider()
p = doc.add_paragraph(); rtl_para(p, 2)
add_run(p, "جمع‌بندی: ", 10.5, True)
add_run(p, "امروز قابلیت‌های کارتابل و دستور کار تکمیل شد، دو باگ مهم گزارش‌شده (گم‌شدن نامه در بایگانی و به‌هم‌ریختگی "
            "متن دستور کار) به‌صورت ریشه‌ای رفع شد و نسخهٔ پوش‌شده روی شاخهٔ main آمادهٔ تست است.", 10.5)

out = "/home/user/reports/گزارش-کار-1405-08-05.docx"
doc.save(out)
print("saved:", out)
