#!/usr/bin/env python3
"""
razor-guard — بررسی سریع خطاهای رایج بیلد (Razor + C#) پیش از کامیت/پوش.

چون در این محیط SDK دات‌نت قابل نصب/اجرا نیست، این اسکریپت سه دسته خطایی را که
قبلاً واقعاً بیلد را شکسته‌اند تشخیص می‌دهد:

1) RZ1011 / RZ2005 — استفادهٔ ناخواسته از نام یک «دایرکتیو» رِیزور در متن/تعبیر
   (مثل @page داخل متن صفحه‌بندی) .
2) بررسی الگوی شکنندهٔ رشتهٔ داخل صفت رِیزور.
   الگوی درست: `@onclick='() => F("x")'` یا `@onclick="@(() => F(\"x\"))"`.

اجرا:  python3 razor-guard.py <repo-root>
"""
import io
import os
import re
import sys

DIRECTIVES = ["page", "using", "inject", "namespace", "implements", "inherits",
              "layout", "attribute", "typeparam", "rendermode", "model", "addTagHelper",
              "removeTagHelper", "tagHelperPrefix", "preservewhitespace"]

ATTR_Q = re.compile(r'@(onclick|onchange|onblur|oninput|onkeydown|onmouseover|bind)(:[\w]+)?="')

problems = []


def walk(root, exts):
    for base, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in
                   {".git", "bin", "obj", "node_modules", ".vs", "wwwroot"}]
        for f in files:
            if f.endswith(exts):
                yield os.path.join(base, f)


def check_directives(path, lines):
    in_comment = False
    for i, ln in enumerate(lines, 1):
        # کامنت‌های رِیزور (@* ... *@) و CSS/رشته‌ها را نادیده بگیر
        if in_comment:
            if "*@" in ln:
                in_comment = False
            continue
        if ln.lstrip().startswith("@*") and "*@" not in ln:
            in_comment = True
            continue
        if ln.lstrip().startswith("@*"):
            continue
        for d in DIRECTIVES:
            tok = "@" + d
            idx = ln.find(tok)
            while idx != -1:
                nxt = ln[idx + len(tok):idx + len(tok) + 1]
                at_start = ln[:idx].strip() == ""
                # @@ escape (مثل @@page در CSS) و رشته‌های داخل کد را رد کن
                if idx > 0 and ln[idx - 1] == "@":
                    idx = ln.find(tok, idx + len(tok))
                    continue
                # دایرکتیو معتبر: ابتدای خط و فقط در سربرگ فایل (۲۵ خط اول)
                if (nxt in ("", " ", "\t", '"')) and (not at_start or i > 25):
                    problems.append(
                        f"{path}:{i}: دایرکتیو «@{d}» در جای نامعتبر (RZ1011/RZ2005): {ln.strip()[:90]}")
                idx = ln.find(tok, idx + 1)


def check_brace_balance(path, text):
    """
    توازن آکولاد در فایل .razor.

    در Razor یک «}» اضافی در بخش markup به‌عنوان متن عادی رندر می‌شود و به‌صورت
    یک «}» سرگردان در پایین صفحه دیده می‌شود (باگ واقعی صفحهٔ «نامهٔ وارده/دریافتی»)،
    در حالی که بیلد خطا نمی‌دهد. کم‌بودن آکولاد هم یعنی بلوک @code/@if بسته نشده است.
    کامنت‌های razor (@* ... *@) پیش از شمارش حذف می‌شوند.
    """
    body = re.sub(r"@\*.*?\*@", "", text, flags=re.S)
    diff = body.count("{") - body.count("}")
    if diff > 0:
        problems.append(f"{path}: {diff} آکولادِ بسته‌نشده «{{» (بلوک @code/@if تمام نشده)")
    elif diff < 0:
        problems.append(f"{path}: {-diff} آکولاد اضافه «}}» — در Razor به‌صورت متن در صفحه رندر می‌شود")


def check_quotes(path, lines):
    for i, ln in enumerate(lines, 1):
        for m in ATTR_Q.finditer(ln):
            rest = ln[m.end():]
            # @onclick="@(() => F(\"x\"))" شکل امنِ escape است — نه خطا
            if rest.startswith("@("):
                continue
            q = rest.find('"')
            if q == -1:
                continue
            nxt = rest[q + 1:q + 2]
            if nxt not in (" ", "\t", ">", "/", ""):
                problems.append(
                    f"{path}:{i}: الگوی شکنندهٔ رشته در صفت رِیزور: {ln.strip()[:90]}")


def main(root):
    for path in walk(root, (".razor",)):
        text = io.open(path, encoding="utf-8").read()
        lines = text.split("\n")
        check_directives(path, lines)
        check_quotes(path, lines)
        check_brace_balance(path, text)
    if problems:
        print(f"❌ {len(problems)} مورد مشکوک:\n")
        for p in problems:
            print(" -", p)
        return 1
    print("✅ هیچ مشکل شناخته‌شده‌ای پیدا نشد (دایرکتیو/توازن/کوتیشن).")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else "."))
