# بازیابی مخزن پس از پاک‌سازی ورک‌اسپیس

> این پوشه (repo-archive) جایگزینِ کپیِ محلیِ مخزن است تا حجم ورک‌اسپیس کم شود.
> **همهٔ کد و کامیت‌ها روی GitHub هستند؛ چیزی از دست نرفته است.**

## وضعیت ریموت در زمان پاک‌سازی

- مخزن: `https://github.com/mohammadforoughifar/TotallCollectionSoftware.git`
- شاخهٔ `main` ریموت = **`650b82d9`** (رفع خطای نگار ذهنی — اسکریپت بارگذاری‌نشده)

## بازیابی سریع (پیشنهادی)

```bash
cd /home/user
git clone --filter=blob:none https://github.com/mohammadforoughifar/TotallCollectionSoftware.git
cd TotallCollectionSoftware
git checkout main          # = 650b82d9
```

> `--filter=blob:none` مخزن را سبک نگه می‌دارد (بلاب‌ها هنگام نیاز دانلود می‌شوند).
> اگر حجم ورک‌اسپیس مهم است، برای کار روی یک فایل هم می‌توان از `--depth 1` استفاده کرد:
> `git clone --depth 1 https://...`

## شاخه‌های محلی و جای آن‌ها

| شاخهٔ محلی | کامیت | روی ریموت؟ |
|---|---|---|
| `main` (قدیمی) | `cc664540` | ❌ فقط در bundle |
| `backup-print-fix` | `c8ad7ddb` | ❌ فقط در bundle |
| `arena/email-filters-perf` | `1161cc97` | ✅ |
| `backup-worktree-20261027` | `8921089f` | ✅ |
| `snapshot-mindflow-2f3d611` | `2f3d611b` | ✅ |
| `snapshot-mindflow-acc1247` | `acc12476` | ✅ |
| `pending/incoming-letter-edit` | `e03fb135` | ✅ (روی main) |
| `pending/workorder-letter-image` | `e03fb135` | ✅ |
| `pending/email-inline-attachments` | `26e13967` | ✅ |
| `pending/workorder-recipients-column` | `17139324` | ✅ |
| `pending/workorder-mine-no-owner` | `0cea80f6` | ✅ |
| `pending/workorder-status-colors` | `22ec144e` | ✅ |
| `pending/mindflow-js-fix` | `650b82d9` | ✅ |

## دو شاخه‌ای که فقط محلی بودند

`local-only-branches.bundle` (۲۲۷ کیلوبایت) شامل کامیت‌های یکتای این دو شاخه است:

- `refs/heads/main` → `cc664540` (نسخهٔ قدیمی با چیدمان `TotallCollectionSoftware/src`)
- `refs/heads/backup-print-fix` → `c8ad7ddb`

بازیابی پس از کلون مخزن:

```bash
git clone https://github.com/mohammadforoughifar/TotallCollectionSoftware.git
cd TotallCollectionSoftware
git fetch /home/user/repo-archive/local-only-branches.bundle \
  main:refs/heads/old-local-main backup-print-fix:refs/heads/old-backup-print-fix
```

> bundle دو پیش‌نیاز دارد که هر دو روی ریموت موجودند:
> `966d1be6` و `682ca051`. اگر مرورگر/سرور این commit‌ها را نداشت،
> اول مخزن کامل را کلون کنید (نه `--depth 1`).

## تغییرات کامیت‌نشدهٔ درختِ محلی

فایل `uncommitted-local-changes.patch` (۱۰۹ کیلوبایت) دیفِ ۸ فایل تغییریافتهٔ کارنشده بود
(دبیرخانه/ایمیل + چند فایل حذف‌شدهٔ letterhead). اعمال:

```bash
git apply /home/user/repo-archive/uncommitted-local-changes.patch
```

## پچ‌های کارهای انجام‌شده

در پوشهٔ `/home/user/patches/`:

| فایل | موضوع |
|---|---|
| `mindflow-js-not-loaded-fix.patch` | رفع خطای `inventoryWorkProjectMindFlow.attachDrag` (همین الان روی main) |
| `workorder-status-colors-22ec144e.patch` | آبی‌شدن «انجام به‌موقع» و سبز شدن «تأیید» |
| `workorder-mine-no-owner-column-0cea80f6.patch` | حذف ستون «دستوردهنده» از تب «دستورهای من» |
| `workorder-recipients-column-17139324.patch` | ستون گیرندگان با آواتار/شمارنده/نوار پاسخ |
| `email-inline-not-attached-26e13967.patch` | تصویر داخل متن ایمیل ضمیمه نشود |
| `workorder-letter-image-e03fb13.patch` | تصویر نامه در شرح دستور کار |
